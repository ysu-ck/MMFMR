
import os
import torch
import argparse
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter

# 导入自定义模块
from nets.model import Model
from utils.WashingtonDataset import WashingtonDataset
from utils.train_one_epoch import train_one_epoch
from utils.evaluate import evaluate
from utils.metrics import plot_confusion_matrix, save_classification_report, save_training_history
from utils.util import NativeScalerWithGradNormCount as NativeScaler


# 使用函数设置设备以提高可读性
def get_device():
    return torch.device('cuda' if torch.cuda.is_available() else 'cpu')


def get_args_parser():
    parser = argparse.ArgumentParser('CNN_TransNet', add_help=False)
    parser.add_argument('--image_size', default=224, type=int, help='image size')
    parser.add_argument('--batch_size', default=16, type=int, help='batch size')
    parser.add_argument('--epochs', default=10, type=int)
    parser.add_argument('--num_workers', default=8, type=int, help='Number of workers for DataLoader')
    parser.add_argument('--data_type', default='colorized_depth')
    parser.add_argument('--optimizer_type', default='SGD', choices=['adam', 'SGD'], help='Optimizer type')
    parser.add_argument('--weight_decay', type=float, default=0.01, help='Weight decay')
    parser.add_argument('--learning_rate', type=float, default=0.001, help='Learning rate')
    parser.add_argument('--dataset_dir', default='./data', help='Path for dataset')
    parser.add_argument('--output_dir', default='./output', help='Path for saving output')
    parser.add_argument('--log_dir', default='./output', help='Path for saving logs')
    parser.add_argument('--train_file', default='data/splits/trial_1_train.txt', help='Training file path')
    parser.add_argument('--test_file', default='data/splits/trial_1_test.txt', help='Test file path')
    parser.add_argument('--pin_memory', action='store_true', help='Pin memory for DataLoader efficiency')
    parser.set_defaults(pin_memory=True)
    return parser


def main(args):

    # 检查 train_file 属性是否存在
    if not hasattr(args, 'train_file'):
        raise AttributeError("args 对象缺少必需的 'train_file' 属性。请确保已在 get_args_parser() 中定义它。")

    device = get_device()

    try:
        # 读取数据集文件
        with open(args.train_file, encoding='utf-8') as f:
            train_lines = f.readlines()
        with open(args.test_file, encoding='utf-8') as f:
            test_lines = f.readlines()
    except FileNotFoundError as e:
        print(f"错误：文件未找到 - {e}")
        return

    train_dataset = WashingtonDataset(train_lines, args.dataset_dir)
    val_dataset = WashingtonDataset(test_lines, args.dataset_dir)

    # 使用DataLoader
    train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True,
                              num_workers=args.num_workers, pin_memory=args.pin_memory, drop_last=True)
    val_loader = DataLoader(val_dataset, batch_size=args.batch_size, shuffle=False,
                            num_workers=args.num_workers, pin_memory=args.pin_memory, drop_last=True)

    model = Model(num_transformer_blocks=2).to(device)
    criterion = torch.nn.CrossEntropyLoss()

    # 优化器选择
    optimizer = {'adam': torch.optim.Adam(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay),
                 'SGD': torch.optim.SGD(model.parameters(), lr=args.learning_rate, momentum=0.9, nesterov=True)}[
        args.optimizer_type]

    os.makedirs(args.log_dir, exist_ok=True)
    os.makedirs(args.output_dir, exist_ok=True)

    log_writer = SummaryWriter(log_dir=args.log_dir)
    loss_scaler = NativeScaler()
    epoch_step_train = len(train_lines) // args.batch_size
    epoch_step_test = len(test_lines) // args.batch_size

    # 定义您的5个类别名称（根据实际数据集修改）
    class_names = ['finesand', 'middlestone', 'mixstone', 'mountainstone', 'stone' ,'basalt_gravel','black_soil','coal','cobblestone','quartz_gravel']

    # 存储训练历史
    train_losses = []
    val_losses = []
    train_accs = []
    val_accs = []

    best_acc = 0
    best_epoch = 0

    for epoch in range(args.epochs):
        print(f'开始第 {epoch + 1}/{args.epochs} 轮训练')

        # 在主训练循环中
        train_stats = train_one_epoch(model, criterion, train_loader, optimizer, device, epoch, loss_scaler,
                                      epoch_step_train)

        # 检查返回值
        if train_stats is not None:
            train_losses.append(train_stats['loss'])
            train_accs.append(train_stats['acc1'])
        else:
            print(f"警告: 第 {epoch + 1} 轮训练没有返回统计信息")
            train_losses.append(0.0)
            train_accs.append(0.0)

        # 评估阶段
        model.eval()
        test_stats = evaluate(val_loader, model, device, epoch, epoch_step_test, criterion)

        # 记录验证指标
        val_losses.append(test_stats['loss'])
        val_accs.append(test_stats['acc1'])

        print(f"测试集准确率: {test_stats['acc1']:.1f}%")
        print(f"测试集损失: {test_stats['loss']:.2f}")

        # 记录到TensorBoard
        if log_writer:
            log_writer.add_scalar('perf/test_acc1', test_stats['acc1'], epoch)
            log_writer.add_scalar('perf/test_loss', test_stats['loss'], epoch)
            log_writer.add_scalar('perf/train_acc1', train_stats['acc1'], epoch)
            log_writer.add_scalar('perf/train_loss', train_stats['loss'], epoch)

        # 保存最佳模型
        if test_stats['acc1'] > best_acc:
            best_acc = test_stats['acc1']
            best_epoch = epoch
            torch.save(model.state_dict(), os.path.join(args.output_dir, "best_model.pth"))

            # 保存最佳epoch的混淆矩阵和分类报告
            plot_confusion_matrix(
                test_stats['confusion_matrix'],
                class_names,
                filename=os.path.join(args.output_dir, 'best_confusion_matrix.png')
            )

            plot_confusion_matrix(
                test_stats['confusion_matrix'],
                class_names,
                filename=os.path.join(args.output_dir, 'best_confusion_matrix_normalized.png'),
                normalize=True
            )

            save_classification_report(
                test_stats['labels'],
                test_stats['predictions'],
                class_names,
                filename=os.path.join(args.output_dir, 'best_classification_report.txt')
            )

        # 保存每个epoch的模型检查点（可选）
        torch.save(model.state_dict(), os.path.join(args.output_dir, f"model_epoch_{epoch + 1}.pth"))

    # 训练完成后保存最终结果
    plot_confusion_matrix(
        test_stats['confusion_matrix'],
        class_names,
        filename=os.path.join(args.output_dir, 'final_confusion_matrix.png')
    )

    save_classification_report(
        test_stats['labels'],
        test_stats['predictions'],
        class_names,
        filename=os.path.join(args.output_dir, 'final_classification_report.txt')
    )

    # 保存训练历史图表
    save_training_history(
        train_losses, val_losses, train_accs, val_accs,
        filename=os.path.join(args.output_dir, 'training_history.png')
    )

    print(f"训练完成! 最佳准确率: {best_acc:.1f}% (第 {best_epoch + 1} 轮)")


if __name__ == '__main__':
    parser = get_args_parser()
    args = parser.parse_args()
    main(args)