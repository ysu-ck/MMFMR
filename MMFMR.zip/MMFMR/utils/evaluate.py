
import torch
from utils.metrics import AverageMeter, accuracy
from tqdm import tqdm


def evaluate(data_loader, model, device, epoch, epoch_step, criterion):
    # 初始化变量来存储预测和标签
    all_preds = []
    all_labels = []

    # 初始化度量器
    model.eval()
    losses = AverageMeter()
    top1 = AverageMeter()

    # 使用 tqdm 进度条
    with tqdm(total=len(data_loader), desc=f'Test: ', postfix=dict, mininterval=0.3) as pbar:
        with torch.no_grad():
            for batch_idx, batch in enumerate(data_loader):
                # 根据训练函数，数据加载器返回 (rgb, depth, target)
                rgb = batch[0]
                depth = batch[1]
                targets = batch[2]

                rgb = rgb.to(device, non_blocking=True)
                depth = depth.to(device, non_blocking=True)
                targets = targets.to(device, non_blocking=True)

                # 前向传播
                outputs = model(rgb, depth)
                loss = criterion(outputs, targets)

                # 记录损失和准确率
                losses.update(loss.item(), rgb.size(0))
                acc1 = accuracy(outputs, targets, topk=(1,))
                top1.update(acc1[0].item() if hasattr(acc1[0], "item") else acc1[0], rgb.size(0))

                # 收集预测和标签
                _, preds = torch.max(outputs, 1)
                all_preds.extend(preds.cpu().numpy())
                all_labels.extend(targets.cpu().numpy())

                # 更新进度条
                pbar.set_postfix(**{
                    'loss': losses.avg.item() if hasattr(losses.avg, "item") else losses.avg,
                    'acc1': top1.avg.item() if hasattr(top1.avg, "item") else top1.avg
                })
                pbar.update(1)

                # 定期打印进度
                if batch_idx % 100 == 0:
                    print(f'测试: [{batch_idx}/{len(data_loader)}]\t'
                          f'损失 {losses.avg.item() if hasattr(losses.avg, "item") else losses.avg:.4f}\t'
                          f'准确率@1 {top1.avg.item() if hasattr(top1.avg, "item") else top1.avg:.3f}')

    # 计算混淆矩阵
    from sklearn.metrics import confusion_matrix
    cm = confusion_matrix(all_labels, all_preds)

    # 返回评估结果
    return {
        'acc1': top1.avg.item() if hasattr(top1.avg, "item") else top1.avg,
        'loss': losses.avg.item() if hasattr(losses.avg, "item") else losses.avg,
        'confusion_matrix': cm,
        'predictions': all_preds,
        'labels': all_labels
    }